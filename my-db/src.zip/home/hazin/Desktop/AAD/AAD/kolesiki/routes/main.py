from flask import Blueprint, render_template, session
from models import User, Product
from utils import get_current_user

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    """Главная страница"""
    current_user = get_current_user()
    products = Product.query.filter_by(is_available=True).limit(6).all()
    
    return render_template('index.html', 
                         current_user=current_user,
                         products=products,
                         user_balance=current_user.balance if current_user else 0)