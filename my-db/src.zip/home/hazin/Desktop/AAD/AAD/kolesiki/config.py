import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Конфигурация приложения"""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'shop_secret_key_123'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'postgresql://kolesiki_user:your_password@localhost:5432/kolesiki_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False